@extends('farmer.Layout.main')

@section('title', 'Dashbord')


@section('content')
<div class="container-fluid">
    <div class="row">

        <div class="col-md-3 col-sm-6 col-12" style="cursor: pointer" data-toggle="modal" data-target="#addNewAdmin">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="fa fa-plus-circle"></i></span>
              <div class="info-box-content">
                <h6 class="info-box-text">Dashbord</h6>

              </div>
            </div>
        </div>
        <div class="col-md-3"></div>

        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="fa fa-user-check"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-success">Active Admin Users</span>
              <span class="info-box-number text-success font-weight-bold">{{$ActiveAdmin}}</span>
              </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
                <span class="info-box-icon bg-danger"><i class="fa fa-user-alt-slash"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text text-danger">Deactive Admin Users</span>
                  <span class="info-box-number text-danger font-weight-bold">{{$DeactiveAdmin}}</span>
                </div>
              </div>
            </div>
        </div>

        <div class="row mt-5">
@foreach ($adminList as $admin)
            <div class="col-lg-3 col-6">
                <!-- small card -->
                <div class='small-box @if($admin->Status==1) bg-primary @else bg-danger @endif'>
                  <div class="inner">
                    <h4>{{$admin->Name}}</h4>

                    <p>{{$admin->TP}}</p>
                    <p>{{$admin->Email}}</p>
                  </div>
                  <div class="icon">
                    <i class="fas fa-user-cog"></i>
                  </div>
                  <a href="/administrator/deactive/{{$admin->idadministreter}}/{{$admin->Status}}" class="small-box-footer">
                    Click Hear @if($admin->Status==1) Deactive @else Active @endif Admin <i class="fas @if($admin->Status==1) fa-eye-slash @else fa-eye @endif ml-1"></i>
                  </a>
                </div>
              </div>
@endforeach

        </div>

    </div>
  </div>
  {{-- add new model --}}
  <div class="modal fade" id="addNewAdmin" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-body p-0">
                <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title"><i class="fa fa-plus-square mr-2" aria-hidden="true"></i>Add New Administrator</h3>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="text-white">&times;</span>
                    </button>
                    </div>

                {{ Form::open(array('url' => '/administrator/Register','method'=>'POST')) }}

                <div class="card-body">

                    <div class="form-group">
                        <label>Administrator Full Name:</label>

                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" name="Name" required id="Name" placeholder="Administrator Full Name">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email address:</label>

                        <div class="input-group">
                              <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            </div>
                            <input type="email" class="form-control" required name="Email" id="Email" placeholder="test@email.com">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Password:</label>

                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                              </div>
                              <input type="password" class="form-control" required name="Password" id="Password" placeholder="Password">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Re Type Password:</label>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                </div>
                                <input type="password" class="form-control" required name="RePassword" id="RePassword" placeholder="Password">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Mobile Phone Number:</label>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                </div>
                                <input type="text" class="form-control" required name="TP" id="TP" placeholder="077 712 3456"
                                data-inputmask="'mask': ['999-999-9999 [x99999]', '+099 99 99 9999[9]-9999']" data-mask>
                            </div>
                          </div>

                      </div>

                      <div class="card-footer m-0">
                          <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div>
{{-- add new model end --}}
<script src="../plugins/jquery/jquery.min.js"></script>
<script src="../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>


<script>
    $(document).ready(function () {

        $("#Password").keydown(function (e) {


           if($('#RePassword').val()!=""){
            if($('#RePassword').val()==$('#Password').val()){
                $('#RePassword').addClass('is-valid')
                $('#Password').addClass('is-valid')
                $('#RePassword').removeClass('is-invalid')
                $('#Password').removeClass('is-invalid')
            }else{
                $('#RePassword').addClass('is-invalid')
                $('#Password').addClass('is-invalid')
                $('#RePassword').removeClass('is-valid')
                $('#Password').removeClass('is-valid')

            }
           }

        });

        $("#RePassword").keyup(function (e) {


            if($('#RePassword').val()==$('#Password').val()){
                $('#RePassword').addClass('is-valid')
                $('#Password').addClass('is-valid')
                $('#RePassword').removeClass('is-invalid')
                $('#Password').removeClass('is-invalid')
            }else{
                $('#RePassword').addClass('is-invalid')
                $('#Password').addClass('is-invalid')
                $('#RePassword').removeClass('is-valid')
                $('#Password').removeClass('is-valid')
            }

        });

    });
  </script>
@endsection
