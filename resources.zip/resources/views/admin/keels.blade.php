@extends('admin.Layout.main')

@section('title', 'Keels Agents')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-shopping-cart text-muted mr-5"></i> All Keels Agent
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-dark">
                        <strong>{{$all}}</strong>
                    </p>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-4 col-xl-2"></div>
        <div class="col-6 col-md-4 col-xl-2"></div>
        <div class="col-6 col-md-4 col-xl-2"></div>
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clone text-muted mr-5"></i> Active Agent
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-secondary">
                        <strong>{{$active}}</strong>
                    </p>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clock-o text-muted mr-5"></i> Deactive
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-primary">
                        <strong>{{$deactive}}</strong>
                    </p>
                </div>
            </a>
        </div>


    </div>

    <div class="row">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row m-2">
                    <div class="col-md-4">
                        <button type="button"  data-toggle="modal" data-target="#addNew" class="btn btn-primary"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add New</button>
                </div>
            </div>
          </div>
          <div class="card-body">
            <table class="table" id="Maintable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Employee No</th>
                        <th>Add DateTime</th>
                        <th class="text-center"><i class="fa fa-wrench" aria-hidden="true"></i></th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $i=0
                    @endphp
                    @foreach ($keelsAgents as $keelsAgent)
                        @php
                            $i=$i+1;
                        @endphp
                    <tr>
                        <td>{{$i}}</td>
                        <td>{{$keelsAgent->keelsAgentName}}</td>
                        <td>{{$keelsAgent->keelsEMPno}}</td>
                        <td>{{$keelsAgent->DateTime}}</td>

                        <td class="text-center">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                 <button class="btn btn-dark btn-sm EditModelTriger " data-row="{{json_encode($keelsAgent)}}" ><i class="fa fa-edit" aria-hidden="true"></i></button>
                                 <button class="btn btn-danger btn-sm DeleteTogal" data-id="{{$keelsAgent->idkeels}}"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                 <button class="btn btn-light btn-sm changePass" data-id="{{$keelsAgent->idkeels}}"><i class="fa fa-key" aria-hidden="true"></i></button>
                                 <button class="btn @if($keelsAgent->Status == 1) btn-success @else btn-secondary @endif btn-sm editToggal" data-id="{{$keelsAgent->idkeels}}" onclick="location.href='/admin/keelsAgent/disable/{{$keelsAgent->idkeels}}'"><i class="fa @if($keelsAgent->Status == 1) fa-eye @else fa-eye-slash @endif" aria-hidden="true"></i></button>
                            </div>
                        </td>
                    </tr>

                    @endforeach
                </tbody>
            </table>
          </div>
        </div>
        </div>
    </div>
</div>



<!-- change Password -->
<div class="modal fade" id="changePass" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Enter Chenge Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                {{ Form::open(array('url' => '/admin/keelsAgent/changePass','method' => 'post'))}}
                <input type="hidden" name="idkeels" id="idkeels">

                <div class="form-group">
                  <label for="newPassword">New Password</label>
                  <input type="password"
                    class="form-control" name="newPassword" id="newPassword" aria-describedby="helpId" placeholder="Password">
                  <small id="helpId" class="form-text text-muted">Use Strong Password</small>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>

            {{ Form::close() }}

            </div>
        </div>
    </div>
</div>
<!-- change Password -->

{{-- model update keels --}}
<div class="modal fade" id="updateMod" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-fromright" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Keels Agent</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            {{ Form::open(array('url' => '/admin/keelsAgent/update','method' => 'post' ))}}
            <input type="hidden" name="idkeels" id="Eidkeels">
            <div class="modal-body">
                <div class="form-group">
                  <label for="keelsAgentName">Agent Name</label>
                  <input type="text"
                    class="form-control" name="keelsAgentName" id="EkeelsAgentName" aria-describedby="helpId" placeholder="First Name">
                </div>


                <div class="form-group">
                  <label for="keelsEMPno">Emp No</label>
                  <input type="text"
                    class="form-control" name="keelsEMPno" id="EkeelsEMPno" aria-describedby="helpId" placeholder="Reg No">

                </div>
                <

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        {{ Form::close() }}
        </div>
    </div>
</div>
{{-- model update keels end --}}

{{-- model add keels --}}
<div class="modal fade" id="addNew" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-fromright" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Keels Agent</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            {{ Form::open(array('url' => '/admin/keelsAgent/add','method' => 'post' ))}}

            <div class="modal-body">
                <div class="form-group">
                  <label for="keelsAgentName">Agent Name</label>
                  <input type="text"
                    class="form-control" name="keelsAgentName" id="keelsAgentName" aria-describedby="helpId" placeholder="First Name">
                </div>

                <div class="form-group">
                  <label for="keelsEMPno">Emp No</label>
                  <input type="text"
                    class="form-control" name="keelsEMPno" id="keelsEMPno" aria-describedby="helpId" placeholder="Reg No">

                </div>


                <div class="form-group">
                  <label for="keelsAgentPassword">Password</label>
                  <input type="password"
                    class="form-control" name="keelsAgentPassword" id="keelsAgentPassword" aria-describedby="helpId" placeholder="Password">
                  <small id="helpId" class="form-text text-muted">use Strong password</small>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        {{ Form::close() }}
        </div>
    </div>
</div>
{{-- model add keels end --}}

{{-- delete Model --}}
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-fromright" role="document">
        <div class="modal-content bg-danger">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-light">Are you Sure Delete This</h5>
            </div>
            <div class="modal-body bg-white">
                 <center>
                    <img class="img-fluid text-center p-5" src="{{ asset('imge/asset/delete.png')}}" alt="">
                </center>
            </div>
            <div class="modal-footer bg-white">
                    <button type="button" class="text-center btn btn-danger" id="deleteBtn">Delete</button>
                    <button type="button" class="text-center btn btn-secondary" data-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
{{-- delete Model end--}}
@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $(".DeleteTogal").click(function (e) {
                e.preventDefault();
                $("#deleteModel").modal('show');
                var getId=$(this).attr("data-id")
                $("#deleteBtn").attr("data-id",getId);


            });
            $("#deleteBtn").click(function (e) {
                e.preventDefault();
                var id=$("#deleteBtn").attr("data-id");
                location.href="/admin/keelsAgent/delete/"+id;
            });
             $('.lightbox').topbox();

             // edit
        $(".EditModelTriger").click(function (e) {
            e.preventDefault();
            $("#updateMod").modal('show');
            var row=JSON.parse($(this).attr("data-row"));

            console.log(row.SuplierName)
            $("#Eidkeels").val(row.idkeels);
            $("#EkeelsAgentName").val(row.keelsAgentName);
            $("#EkeelsEMPno").val(row.keelsEMPno);
        });

  $(".changePass").click(function (e) {
            e.preventDefault();
            $("#changePass").modal('show');
            $("#idkeels").val($(this).attr("data-id"));
        });

        });
    </script>
@endsection
