@extends('admin.Layout.main')

@section('title', 'Dashboard')


@section('content')
<div class="container-fluid">
   <div class="row">
       <div class="col-md-12 text-center bg-dark p-5">
           <h2>Wellcome Back</h2>
           <h3>{{request()->session()->get('AdminName')}}</h3>
       </div>
   </div>
</div>
  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDetYAHVFFW-fBj_STo3C9a6Nb7lFZxiHc&callback=initMap&libraries=&v=weekly" defer></script>
  <script>
    let map;


    function initMap() {


        const myLatLng = {
            lat: 6.053519,
            lng: 80.220978
        };

        map = new google.maps.Map(document.getElementById("map"), {
            center: myLatLng,
            zoom: 15
        });

        var marker = new google.maps.Marker({
                  position: myLatLng,

                map,
            animation: google.maps.Animation.BOUNCE,
            title: "Hello World!"
        });

   var database = firebase.database();
  var LocationRef = firebase.database().ref("company"+{{request()->session()->get('Company')}}+"/Location");
  LocationRef.on('value', function(snapshot) {


                const val = snapshot.val()
                val.forEach(element => {
                  const myLatLng = {
                      lat: parseFloat(element.latitude),
                    lng: parseFloat(element.longitude)
                 };
                 marker.setPosition(myLatLng);
              });

      });





    }
    </script>
@endsection
