<!DOCTYPE html>
<html>
<head>
    @if(request()->session()->get('FarmerLogin'))
    <script>window.location = "/farmer/login";</script>
    @endif
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>{{ env('APP_NAME')}} | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{{ URL::asset('plugins/toastr/toastr.min.css') }}">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href=""><b>{{ env('APP_NAME')}} - DOA Officer </b> Login</a>
  </div>

  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>
      {{ Form::open(array('url' => '/doa/login/prosess','method'=>'post')) }}
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="doaEmail" id="doaEmail" placeholder="doaEmail">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-id-card"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="doaPassword" id="doaPassword" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
        {{ Form::close() }}



      <!-- /.social-auth-links -->


    </div>
    <!-- /.login-card-body -->
  </div>
  <h6 class="text-center">Copyright © 2020 <a href="">{{env('APP_NAME')}}</a>. All rights reserved.</h6>
</div>
<!-- /.login-box -->


<script type="text/javascript" src="{{ URL::asset('plugins/jquery/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('plugins/toastr/toastr.min.js') }}"></script>

<script>
    $(document).ready(function () {


        @if(Session::has('message'))
      var type = "{{ Session::get('alert-type', 'info') }}";

      switch(type){

          case 'success':
          toastr.success("{{ Session::get('message') }}")
            break;

          case 'error':
          toastr.error("{{ Session::get('message') }}")
            break;

          case 'info':
          toastr.info("{{ Session::get('message') }}")
            break;

          case 'warning':
          toastr.warning("{{ Session::get('message') }}")
            break;
      }
    @endif
    toastr.options.closeButton = true;

    });
</script>
</body>
</html>
