@extends('keels.Layout.main')

@section('title', 'Select Farmer')

@section('content')
<div style="margin-top: 60px"></div>
<div class="container w-100">
    <div class="row">
        <div class="col-md-12">
            <div class="w-50 card m-auto">
                 <div class="card-body"  style="height: 400px; background:linear-gradient(0deg, rgba(0, 0, 0, 0.3), rgba(255, 0, 150, 0.3)), url({{ URL::asset('imge/asset/smsbg.jpg') }});  overflow: scroll; background-repeat: no-repeat; backgroun-size:cover;">


                    @foreach ($msg as $msgSet)
                        @if($msgSet->Status==1)
                            <div class="row ml-3 mr-3 mb-1 d-flex  @if($msgSet->IsFromKeels==1)flex-row-reverse @else flex-row @endif" >
                            <div class="d-inline-flex p-2 @if($msgSet->IsFromKeels==1)bg-secondary @else bg-success @endif rounded" >
                                <h6 class="text-light">{{$msgSet->msg}}</h6>
                                {{-- @if($msgSet->IsFromKeels==1)
                                <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle p-0 ml-3" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="/keels/msg/delete/{{$msgSet->idmaseges}}">Delete</a>
  </div>
</div>
                                @endif --}}

                            </div>
                        </div>
                        @else
                        <div class="row ml-3 mr-3 mb-1 d-flex  @if($msgSet->IsFromKeels==1)flex-row-reverse @else flex-row @endif" >
                            <div class="card d-inline"><i class="fa fa-ban" aria-hidden="true"></i> This message was deleted</div>
                        </div>
                        @endif
                    @endforeach

                </div>
                <div class="card-footer">
                    {{ Form::open(array('url' => '/keels/msg/send','method' => 'post'))}}
                    <div class="row">
                        <div class="input-group mb-3">

                            <input type="hidden" name="farmer" id="farmer" value="{{$farmer}}">
                            <input type="text" class="form-control" name="msg" id="msg" placeholder="Type Your Massege"aria-describedby="basic-addon2">
                            <div class="input-group-append">
                             <button type="submit" class="btn btn-primary btn-circle"><i class="fa fa-rocket " aria-hidden="true"></i></button>
                        </div>

                    </div>
                </div>
                {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection
