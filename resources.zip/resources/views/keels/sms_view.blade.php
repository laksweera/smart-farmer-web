@extends('keels.Layout.main')

@section('title', 'Select Farmer')

@section('content')
<div class="container mt-1 ">
    <div class="row">
        <div class="col-12">
            <h3>Recent Chats</h3>
            <div class="list-group w-50">
    @foreach ($users as $user)

        <a href="/keels/msg/{{$user->idfarmer}}" class="list-group-item list-group-item-action m-1"> <i class="fa fa-address-book fa-3x mt-2 mr-4" aria-hidden="true"></i><span class="fa-2x">{{$user->FullName}}</span></a>
    @endforeach
</div>
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection
