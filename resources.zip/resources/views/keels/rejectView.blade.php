@extends('keels.Layout.main')

@section('title', 'Reject View')


@section('content')
<div class="container">
    <div class="row">
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-shopping-cart text-muted mr-5"></i> All Product
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-dark">
                        <strong>{{$all}}</strong>
                    </p>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-4 col-xl-2"></div>
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clone text-muted mr-5"></i> Not Rated
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-secondary">
                        <strong>{{$all}}</strong>
                    </p>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clock-o text-muted mr-5"></i> Pending
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-primary">
                        <strong>{{$pending}}</strong>
                    </p>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-check text-muted mr-5"></i> Sold
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-success">
                        <strong>{{$broughted}}</strong>
                    </p>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-ban text-muted mr-5"></i> Rejected
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-danger">
                        <strong>{{$Rejected}}</strong>
                    </p>
                </div>
            </a>
        </div>

    </div>

    <div class="row">
        <div class="col-md-4" style="height: 500px;">
            @foreach($productRecode as $row)
            <div class="row shadow p-3 mb-5 bg-white rounded mt-1" onclick="showFarmerModel(
                    '{{$row->idProduct_Recode}}',
                    '{{$row->FullName}}',
                    '{{$row->farmer_idfarmer}}',
                    '{{$row->DistrictName}}',
                    '{{$row->Address1}}',
                    '{{$row->Address2}}',
                    '{{$row->City}}',
                    '{{$row->ZipCode}}',
                    '{{$row->FDateTime}}',
                    '{{$row->productName}}',
                    '{{$row->unitCount}}',
                    '{{$row->FlagNo}}',
                    '{{$row->IsBrought}}',
                    '{{$row->IsReject}}',
                    '{{$row->IsMarkedForBuy}}',
                    '{{$row->PDateTime}}',
                    '{{$row->Discription}}',
                    '{{$row->pickedDate}}'

                )">
                <div class="col-6">
                <span> <i class="fa fa-user text-primary mr-1" aria-hidden="true"></i> <b>{{$row->FullName}}</b>  </span><br>
                <span> <i class="fa fa-map text-primary mr-1" aria-hidden="true"></i> <b>{{$row->DistrictName}}</b>  </span><br>



                </div>
                   <div class="col-4">
                <span> <i class="fa fa-shopping-bag text-primary mr-1" aria-hidden="true"></i> <b>{{$row->productName}}</b>  </span><br>
                <span> <i class="fa fa-dollar-sign text-primary mr-1" aria-hidden="true"></i> <b>{{$row->unitCount}} kg</b>  </span><br>
                </div>


                <div class="" style="position: absolute; top: 15px; right: 5px;">
                    <i class="fa fa-flag fa-2x" style="position: absolute; right: 10px; color:
                            @switch($row->FlagNo)
                            @case("0")
                                #6b7078
                                @break
                            @case("1")
                                #f50a0a
                                @break
                            @case("2")
                                #f55c0a
                                @break
                            @case("3")
                                #f5e10a
                                @break
                            @case("4")
                                #26c93c
                                @break
                            @default

                        @endswitch
                        " aria-hidden="true"></i>
                </div>
            </div>
            @endforeach
        </div>

        <div class="col-md-8" style="height: 500px;">
            <div id="map" style="height: 100%;width: 100%;"></div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="farmerD" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body">
                     <button style="position: absolute; right: 5px; top: 5px" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-dark p-1">
                                    <h5 class="text-light m-0 ml-2">Product Deatils</h5>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" name="productID" id="productID">
                                    <h6>Type : <span id="p_type"></span></h6>
                                    <h6>Quntity : <span id="p_qunty"></span></h6>
                                    <h6>Picked Date : <span id="p_date"></span></h6>
                                    <h6>Rate : <i class="fa fa-flag" id="rate" aria-hidden="true"></i></h6>
                                    <h6 class="mb-1">Status : <span id="status" class="badge" style="color: rgb(252, 252, 252); "></span></h6>
                                </div>
                                <div class="card-footer p-1 ">
                                    <span class="text-muted">Aded Date -  <span id="p_add"></span></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header bg-dark p-1">
                                    <h5 class="text-light m-0 ml-2">Farmer Deatils</h5>
                                </div>
                                <div class="card-body">
                                    <h6>Name :  <span id="f_name"></span></h6>
                                    <h6>District : <span id="F_d"></span></h6>
                                    <h6 class="">Address :</h6>
                                    <address class="ml-5"> <span id="a_1"></span> <br> <span id="a_2"></span> <br>  <span id="city"></span> <span id="zip"></span></address>
                                                   <a id="url" class="btn btn-primary goTo sms" style="position: absolute; top: 40px;right: 10px">
                                            <i class="fa fa-paper-plane fa-2x" aria-hidden="true"></i>
                                        </a>
                                </div>
                                <div class="card-footer p-1 ">
                                    <span class="text-muted">Joined Date -  <span id="f_join"></span></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row card">
                        <p id="Discription" class="p-4"></p>
                    </div>


                        <div class="row" id="imageList">

                        </div>



            </div>
            <div class="modal-footer">
                {{-- <button class="btn btn-success" id="sucess"> Mark For Buy</button>
                <button class="btn btn-danger" id="reject">Reject</button> --}}
            </div>

        </div>
    </div>
</div>

@endsection

@section('script')
    <script src="{{ URL::asset('plugins/OwlCarousel2-2.3.4/dist/owl.carousel.min.js')}}"></script>

 <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDetYAHVFFW-fBj_STo3C9a6Nb7lFZxiHc&callback=initMap&libraries=&v=weekly"
      defer
    ></script>
    <script>
        $(document).ready(function () {
        $("#imageList").owlCarousel();

            $("#reject").click(function (e) {
                e.preventDefault();
                $.ajax({
                    type: "get",
                    url: "/reject/"+$("#productID").val(),
                    success: function (response) {
                        location.href="/keels/MapView";
                    }
                });

            });

            $("#sucess").click(function (e) {
                e.preventDefault();
                $.ajax({
                    type: "get",
                    url: "/sucsess/"+$("#productID").val(),
                    success: function (response) {
                        location.href="/keels/MapView";
                    }
                });

            });

            $(".flagSelector").click(function (e) {
                $(".flagSelector").css('border', "0px solid #0000");
                $(this).css('border', "1px solid #00000");
                e.preventDefault();
                $.ajax({
                    type: "get",
                    url: "/flag/"+$("#productID").val()+"/"+$(this).attr("data-flagNo"),
                    success: function (response) {
                                                location.href="/keels/MapView";

                    }
                });

            });


             $('.lightbox').topbox();
        });

        let map;

        function initMap() {
          map = new google.maps.Map(document.getElementById("map"), {
            center: { lat:7.8731, lng: 80.7718},
            zoom: 8,
          });

          @foreach($productRecode as $item)

var lat ={{$item->latitude}};
var lng= {{$item->Longitude}};

                 @switch($item->FlagNo)
                            @case("0")
                            var icon="{{ asset('/imge/asset/flagMaker/falg-0.png')}}";

                                @break
                            @case("1")
                            var icon="{{ asset('/imge/asset/flagMaker/falg-1.png')}}";

                                @break
                            @case("2")
                            var icon="{{ asset('/imge/asset/flagMaker/falg-2.png')}}";

                                @break
                            @case("3")
                            var icon="{{ asset('/imge/asset/flagMaker/falg-3.png')}}";

                                @break
                            @case("4")
                            var icon="{{ asset('/imge/asset/flagMaker/falg-4.png')}}";

                                @break
                            @default

                        @endswitch


            new google.maps.Marker({
                position:  {lat:lat , lng:lng } ,
                map,
                icon:icon,
                title: "{{$item->FullName}}",
            }).addListener("click", () => {
                // var obj={{json_encode($item)}};
                showFarmerModel(
                     '{{$item->idProduct_Recode}}',
                    '{{$item->FullName}}',
                    '{{$item->farmer_idfarmer}}',
                    '{{$item->DistrictName}}',
                    '{{$item->Address1}}',
                    '{{$item->Address2}}',
                    '{{$item->City}}',
                    '{{$item->ZipCode}}',
                    '{{$item->FDateTime}}',
                    '{{$item->productName}}',
                    '{{$item->unitCount}}',
                    '{{$item->FlagNo}}',
                    '{{$item->IsBrought}}',
                    '{{$item->IsReject}}',
                    '{{$item->IsMarkedForBuy}}',
                    '{{$item->PDateTime}}',
                    '{{$item->Discription}}',
                    '{{$item->pickedDate}}'

                );
            });

            @endforeach
        }

        function showFarmerModel(id,farmerName,farmerID,District,address1,address2,city,zip,joinDate,Type,Quntiti,rate,IsBrought,IsReject,IsMarkForBrought,AddDate,Discription,Picked){
                $("#f_name").html(farmerName);
                $("#F_d").html(District);
                $("#a_1").html(address1);
                $("#a_2").html(address2);
                $("#city").html(city);
                $("#zip").html(zip);
                $("#f_join").html(joinDate);

                $("#p_type").html(Type);
                $("#p_qunty").html(Quntiti);
                $("#p_add").html(AddDate);
                $("#p_date").html(Picked);
                $("#Discription").html(Discription);
                $("#url").attr("href","/keels/msg/"+farmerID);


                switch(rate) {
                        case "0":

                        $("#rate").css("color","#6b7078");
                        $(".flagSelector").css('border', "0px solid #0000");
                        $("#flag0").css('border', "1px solid #00000");

                    break;
                        case "1":
                        $("#rate").css("color","#f50a0a");
                        $(".flagSelector").css('border', "0px solid #00000");
                        $("#flag1").css('border', "1px solid #0000");
                    break;
                        case "2":
                        $("#rate").css("color","#f55c0a");
                        $(".flagSelector").css('border', "0px solid #00000");
                        $("#flag2").css('border', "1px solid #0000");
                    break;
                        case "3":
                        $("#rate").css("color","#f5e10a");
                        $(".flagSelector").css('border', "0px solid #00000");
                        $("#flag3").css('border', "1px solid #0000");
                    break;
                        case "4":
                        $("#rate").css("color","#26c93c");
                        $(".flagSelector").css('border', "0px solid #00000");
                        $("#flag4").css('border', "1px solid #0000");
                    break;
                                }


                         if (IsMarkForBrought==1) {
                            if (IsBrought==1) {
                                $("#status").html("Brought");
                                $("#status").css("background-color","#35ab54");

                            }else{
                                $("#status").html("Mark For Buy");
                                $("#status").css("background-color","#e4e809");
                            }
                         }else{
                            if (IsReject==1) {
                                $("#status").html("Rejected");
                                $("#status").css("background-color","#e83209");
                            }else{
                                $("#status").html("Panding");
                                $("#status").css("background-color","#242323");
                            }
                         }
                            $("#productID").val(id)
                              $("#imageList").empty();
                         $.ajax({
                             type: "get",
                             url: "/imageList/"+id,
                             success: function (response) {
                                response.forEach(element => {

                                     $("#imageList").append("<div class='col-4'><img class='img-fluid d-inline p-4' src='"+element.ImageUrl+"' ></div>");

                                // console.log(element.ImageUrl)
                                });
                             }
                         });

                $("#farmerD").modal('show');
        }
    </script>
@endsection
