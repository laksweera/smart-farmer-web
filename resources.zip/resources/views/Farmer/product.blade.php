@extends('farmer.Layout.main')

@section('title', 'Producte')


@section('content')
<div class="container">
    <div class="row">
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-shopping-cart text-muted mr-5"></i> All Product
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-dark">
                        <strong>{{$all}}</strong>
                    </p>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-4 col-xl-2"></div>
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clone text-muted mr-5"></i> Not Rated
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-secondary">
                        <strong>{{$all}}</strong>
                    </p>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-clock-o text-muted mr-5"></i> Pending
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-primary">
                        <strong>{{$pending}}</strong>
                    </p>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-check text-muted mr-5"></i> Sold
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-success">
                        <strong>{{$broughted}}</strong>
                    </p>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-xl-2">
            <a class="block block-link-pop text-center" href="javascript:void(0)">
                <div class="block-content bg-body-light">
                    <p class="font-w600">
                        <i class="fa fa-ban text-muted mr-5"></i> Rejected
                    </p>
                </div>
                <div class="block-content">
                    <p class="font-size-h1 text-danger">
                        <strong>{{$Rejected}}</strong>
                    </p>
                </div>
            </a>
        </div>

    </div>
    <div class="row p-3 mr-2 text-center">
            <div class="p-3"></div>
        <i class="fa fa-flag" style="color: #6b7078; font-size: 25px" aria-hidden="true"></i>
            <span class="pl-2 pr-5">Not Rated</span>
            <div class="p-3"></div>
        <i class="fa fa-flag" style="color: #f50a0a; font-size: 25px" aria-hidden="true"></i>
            <span class="pl-2 pr-5">Bad Rated</span>
            <div class="p-3"></div>
        <i class="fa fa-flag" style="color: #f55c0a; font-size: 25px" aria-hidden="true"></i>
            <span class="pl-2 pr-5">Medium Rated</span>
            <div class="p-3"></div>
        <i class="fa fa-flag" style="color: #f5e10a; font-size: 25px" aria-hidden="true"></i>
            <span class="pl-2 pr-5">Top Rated</span>
            <div class="p-3"></div>
        <i class="fa fa-flag" style="color: #26c93c; font-size: 25px" aria-hidden="true"></i>
            <span class="pl-2 pr-5">Super Top Rated</span>
    </div>
    <div class="row">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row m-2">
                    <div class="col-md-4">
                        <button type="button" class="btn btn-primary" onclick="location.href='/farmer/product/AddNewView'"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add New</button>
                </div>
            </div>
          </div>
          <div class="card-body">
            <table class="table" id="Maintable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Product Type</th>
                        <th>size</th>
                        <th>Product Discription</th>
                        <th>Piked Date</th>
                        <th>Add DateTime</th>
                        <th class="text-center">Rate</th>
                        <th class="text-center">ImageView</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $i=0
                    @endphp
                    @foreach ($productRecode as $item)
                        @php
                            $i=$i+1;
                        @endphp
                    <tr>
                        <td>{{$i}}</td>
                        <td>{{$item->ProductName}}</td>
                        <td>{{$item->unitCount}} {{$item->MesurementSymbol}}</td>
                        <td>{{$item->Discription}}</td>
                        <td>{{$item->pickedDate}}</td>
                        <td>{{$item->DateTime}}</td>
                        <td class="text-center"><i class="fa fa-2x fa-flag" style="color:
                            @switch($item->FlagNo)
                            @case(0)
                                #6b7078
                                @break
                            @case(1)
                                #f50a0a
                                @break
                            @case(2)
                                #f55c0a
                                @break
                            @case(3)
                                #f5e10a
                                @break
                            @case(4)
                                #26c93c
                                @break
                            @default

                        @endswitch
                            "aria-hidden="true"></i></td>
                        <td class="text-center">
                            @php
                                 $images=Illuminate\Support\Facades\DB::table('image')
                                                                        ->where("product_recode_idProduct_Recode", $item->idProduct_Recode)
                                                                        ->get();
                                    $img=0;
                            @endphp
                                @foreach ($images as $image)
                                    @php
                                        $img=$img+1;
                                    @endphp
                                    <a href="{{ asset($image->ImageUrl)}}" class="btn btn-primary btn-sm lightbox @if($img!=1) d-none @endif" aria-haspopup="dialog" data-lightbox-gallery="imageID-{{$item->idProduct_Recode}}"><i class="fas fa-file-image" aria-hidden="true"></i></a>
                                @endforeach
                        </td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                 <button class="btn btn-dark btn-sm editTogel" onclick="location.href='/farmer/product/edit/{{$item->idProduct_Recode}}'"><i class="fas fa-edit" aria-hidden="true"></i></button>
                                 <button class="btn btn-danger btn-sm DeleteTogal" data-id="{{$item->idProduct_Recode}}"><i class="fa fa-times" aria-hidden="true"></i></button>
                            </div>
                        </td>
                    </tr>

                    @endforeach
                </tbody>
            </table>
          </div>
        </div>
        </div>
    </div>
</div>

{{-- delete Model --}}
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-fromright" role="document">
        <div class="modal-content bg-danger">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-light">Are you Sure Delete This</h5>
            </div>
            <div class="modal-body bg-white">
                 <center>
                    <img class="img-fluid text-center p-5" src="{{ asset('imge/asset/delete.png')}}" alt="">
                </center>
            </div>
            <div class="modal-footer bg-white">
                    <button type="button" class="text-center btn btn-danger" id="deleteBtn">Delete</button>
                    <button type="button" class="text-center btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
{{-- delete Model end--}}
@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $(".DeleteTogal").click(function (e) {
                e.preventDefault();
                $("#deleteModel").modal('show');
                var getId=$(this).attr("data-id")
                $("#deleteBtn").attr("data-id",getId);


            });
            $("#deleteBtn").click(function (e) {
                e.preventDefault();
                var id=$("#deleteBtn").attr("data-id");
                location.href="/farmer/product/delete/"+id;
            });
             $('.lightbox').topbox();
        });
    </script>
@endsection
