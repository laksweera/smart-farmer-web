@extends('farmer.Layout.main')

@section('title', 'Producte Edit')


@section('content')
{{ Form::open(array('url' => '/farmer/product/AddNewView/update','method' => 'post', 'enctype'=>"multipart/form-data" ))}}

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Product Details
                </div>
              <div class="card-body">
                <div class="form-group">
                    <input type="hidden" name="idProduct_Recode" value="{{$idProduct_Recode}}">
                  <label for="product_idproduct">Product Type</label>
                  <select class="form-control" name="product_idproduct" id="product_idproduct">
                    <option></option>
                    @foreach ($productType as $product)
                        <option @if($product->idProduct==$productRecode->product_idproduct)selected @endif value="{{$product->idProduct}}">{{$product->ProductName}}</option>
                    @endforeach
                  </select>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-8">
                            <label for="unitCount">Units/Size / Volume</label>
                            <input type="text"
                              class="form-control" name="unitCount" value="{{$productRecode->unitCount}}" id="unitCount" aria-describedby="helpId" placeholder="">
                        </div>
                        <div class="col-4">
                            <label for="Mesurement_idMesurement">Measurement Units</label>
                                <select class="form-control" name="Mesurement_idMesurement" id="Mesurement_idMesurement">
                                    <option></option>
                                @foreach ($mesurementS as $mesurement)
                                    <option @if($mesurement->idMesurement==$productRecode->Mesurement_idMesurement)selected @endif  value="{{$mesurement->idMesurement}}">{{$mesurement->MesurementName}}</option>
                                @endforeach
                                </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                  <label for="Discription">Description</label>
                  <textarea class="form-control" name="Discription"  id="Discription" rows="3">{{$productRecode->Discription}}</textarea>
                </div>
                <div class="form-group">
                  <label for="pickedDate">Product Picked Date</label>
                  <input type="text"
                  class="form-control" name="pickedDate" value="{{$productRecode->pickedDate}}" id="pickedDate" aria-describedby="helpId" >
                </div>

            </div>
        </div>


        <div class="card">
            <div class="card-body">
                <div class="row">
                    <button class="btn btn-primary m-2" id="appendFilebtn"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Image</button>
                    <span class="d-flex align-items-center">Click add new image for uplode image</span>
                </div>
                <div id="fileAppend"></div>
            </div>
        </div>

    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="fa fa-info-circle text-info" aria-hidden="true"></i> * Place Map Maker pin in to Your Locations
            </div>
            <div class="form-group row">
                <div class="col-md-12">
                    <div id="current"><input type="hidden" id="lng" value="{{$productRecode->Longitude}}" name="Longitude"></div>
                    <div id="current"><input type="hidden" id="lat" value="{{$productRecode->latitude}}" name="latitude"></div>
                    <div id='map' style="height: 300px; width: 100%;"></div>
                </div>
            </div>

        </div>
        <div class="card mt-2">
            <div class="card-header">
                Images List   @php
                                $img=0;
                               @endphp
                                @foreach ($productImg as $image)
                                    @php
                                        $img=$img+1;
                                    @endphp
                                    <a href="{{ asset($image->ImageUrl)}}" class="ml-5 btn btn-primary btn-sm lightbox @if($img!=1) d-none @endif" aria-haspopup="dialog" data-lightbox-gallery="galleryEdit"><i class="fa fa-file-image-o" aria-hidden="true"></i></a>
                                @endforeach
            </div>
            <div class="card-body">
                <div class="row">
                    @foreach ($productImg as $imageTumb)
                        <div class="col-md-4 m-2 rounded" id="Img{{$imageTumb->idImage}}">
                            <button class="btn btn-sm btn-danger DeleteTogal" data-id="{{$imageTumb->idImage}}" style="position: absolute;"><i class="fa fa-trash" aria-hidden="true"></i></button>
                            <img src="{{ asset($imageTumb->ImageUrl)}}" class="img-fluid" alt="">
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

    </div>
</div>



<div class="row p-3">
    <button type="submit" class="btn btn-primary btn-lg">Update</button>
</div>
{{ Form::close() }}
</div>

{{-- image delete Model --}}
<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-fromright" role="document">
        <div class="modal-content bg-danger">
            <div class="modal-header bg-danger">
                <h5 class="modal-title text-light">Are you Sure Delete This</h5>
            </div>
            <div class="modal-body bg-white">
                 <center>
                    <img class="img-fluid text-center p-5" src="{{ asset('imge/asset/delete.png')}}" alt="">
                </center>
            </div>
            <div class="modal-footer bg-white">
                    <button type="button" class="text-center btn btn-danger" id="deleteBtn">Delete</button>
                    <button type="button" class="text-center btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
{{-- image delete Model end--}}
@endsection
@section('script')
<script type="text/javascript" src="{{ URL::asset('plugins/select2/js/select2.full.min.js') }}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDetYAHVFFW-fBj_STo3C9a6Nb7lFZxiHc&callback=initMap&libraries=&v=weekly" defer></script>

<script>

    $(document).ready(function () {
        $("#product_idproduct").select2({
            placeholder: "Select a Product Type",
            allowClear: true
        });
        $("#Mesurement_idMesurement").select2({
            placeholder: "Select a Product Type",
            allowClear: true
        });
        $("#pickedDate").flatpickr({
            inline: true
        });

        $("#appendFilebtn").click(function (e) {
            e.preventDefault();
              var appen="<div class='row m-4'>"
                  +"<input type='file' class='form-controler-file' name='Image[]'>"
                  +"</div>"
                $("#fileAppend").append(appen);

        });
             $('.lightbox').topbox();


              $(".DeleteTogal").click(function (e) {
                e.preventDefault();
                $("#deleteModel").modal('show');
                var getId=$(this).attr("data-id")
                $("#deleteBtn").attr("data-id",getId);

            });

              $("#deleteBtn").click(function (e) {
                e.preventDefault();
                var id=$("#deleteBtn").attr("data-id");

                $.ajax({
                    type: "get",
                    url: "/farmer/product/img/"+id,
                    success: function (response) {
                         if(response==1){
                            $("#Img"+id).fadeOut();
                            $("#deleteModel").modal('hide');
                             Codebase.helpers('notify', {
                                align: 'right',             // 'right', 'left', 'center'
                                from: 'top',                // 'top', 'bottom'
                                type: 'success',               // 'info', 'success', 'warning', 'danger'
                                icon: 'fa fa-check-circle mr-5',    // Icon class
                                message: "Sucsessfully Remove Image"
                            });
                         }
                    }
                });

            });

    });

function initMap() {
              // The location of Uluru
              const postion = { lat: {{$productRecode->latitude}}, lng: {{$productRecode->Longitude}} };
              // The map, centered at Uluru
              const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 6,
                center: postion,
              });
              // The marker, positioned at Uluru
              const marker = new google.maps.Marker({
                position: postion,
                map: map,
                 draggable: true
              });
var lat = marker.getPosition().lat();
var lng = marker.getPosition().lng();


google.maps.event.addListener(marker,'drag',function(event) {
    document.getElementById('lat').value = event.latLng.lat();
    document.getElementById('lng').value = event.latLng.lng();

});

google.maps.event.addListener(marker,'dragend',function(event)
        {
    document.getElementById('lat').value =event.latLng.lat();
    document.getElementById('lng').value =event.latLng.lng();

});
                }

</script>
@endsection
