@extends('farmer.Layout.main')

@section('title', 'Producte')


@section('content')
{{ Form::open(array('url' => '/farmer/product/AddNewView/save','method' => 'post', 'enctype'=>"multipart/form-data" ))}}

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Product Details
                </div>
              <div class="card-body">
                <div class="form-group">
                  <label for="product_idproduct">Product Type</label>
                  <select class="form-control" name="product_idproduct" id="product_idproduct">
                    <option></option>
                    @foreach ($productType as $product)
                        <option value="{{$product->idProduct}}">{{$product->ProductName}}</option>
                    @endforeach
                  </select>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-8">
                            <label for="unitCount">Units/Size / Volume</label>
                            <input type="text"
                              class="form-control" name="unitCount" id="unitCount" aria-describedby="helpId" placeholder="">
                        </div>
                        <div class="col-4">
                            <label for="Mesurement_idMesurement">Measurement Units</label>
                                <select class="form-control" name="Mesurement_idMesurement" id="Mesurement_idMesurement">
                                    <option></option>
                                @foreach ($mesurementS as $mesurement)
                                    <option value="{{$mesurement->idMesurement}}">{{$mesurement->MesurementName}}</option>
                                @endforeach
                                </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                  <label for="Discription">Description</label>
                  <textarea class="form-control" name="Discription" id="Discription" rows="3"></textarea>
                </div>
                <div class="form-group">
                  <label for="pickedDate">product Picked Date</label>
                  <input type="text"
                  class="form-control" name="pickedDate" id="pickedDate" aria-describedby="helpId" >
                </div>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="fa fa-info-circle text-info" aria-hidden="true"></i> * Place Map Maker pin in to Your Locations
            </div>
            <div class="form-group row">
                <div class="col-md-12">
                    <div id="current"><input type="hidden" id="lng" value="80.7718" name="Longitude"></div>
                    <div id="current"><input type="hidden" id="lat" value="7.8731" name="latitude"></div>
                    <div id='map' style="height: 300px; width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <button class="btn btn-primary m-2" id="appendFilebtn"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Image</button>
                    <span class="d-flex align-items-center">Click add new image for uplode image</span>
                </div>
                <div id="fileAppend"></div>
            </div>
        </div>
    </div>
</div>

<div class="row p-3">
    <button type="submit" class="btn btn-primary btn-lg">Save</button>
</div>
{{ Form::close() }}
</div>
{{-- image Model end--}}
@endsection

@section('script')
<script type="text/javascript" src="{{ URL::asset('plugins/select2/js/select2.full.min.js') }}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDetYAHVFFW-fBj_STo3C9a6Nb7lFZxiHc&callback=initMap&libraries=&v=weekly" defer></script>
<script>
    $(document).ready(function () {
        $("#product_idproduct").select2({
            placeholder: "Select a Product Type",
            allowClear: true
        });
        $("#Mesurement_idMesurement").select2({
            placeholder: "Select a Product Type",
            allowClear: true
        });
        $("#pickedDate").flatpickr({
            inline: true
        });

        $("#appendFilebtn").click(function (e) {
            e.preventDefault();
              var appen="<div class='row m-4'>"
                  +"<input type='file' class='form-controler-file' name='Image[]'>"
                  +"</div>"
                $("#fileAppend").append(appen);

        });
    });


                            // Initialize and add the map
            function initMap() {
              // The location of Uluru
              const postion = { lat: 7.8731, lng: 80.7718 };
              // The map, centered at Uluru
              const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 6,
                center: postion,
              });
              // The marker, positioned at Uluru
              const marker = new google.maps.Marker({
                position: postion,
                map: map,
                 draggable: true
              });
var lat = marker.getPosition().lat();
var lng = marker.getPosition().lng();


google.maps.event.addListener(marker,'drag',function(event) {
    document.getElementById('lat').value = event.latLng.lat();
    document.getElementById('lng').value = event.latLng.lng();

});

google.maps.event.addListener(marker,'dragend',function(event)
        {
    document.getElementById('lat').value =event.latLng.lat();
    document.getElementById('lng').value =event.latLng.lng();

});
                }
</script>
@endsection
