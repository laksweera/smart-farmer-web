@extends('farmer.Layout.main')

@section('title', 'Dashboard')


@section('content')
<div class="container-fluid">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
          <div class="inner">
            <h3>{{$pendin}}</h3>

            <p>Not Rated Yet</p>
          </div>
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
          <div class="inner">
            <h3>{{$Brought}}</h3>

            <p>Brought</p>
          </div>
          <div class="icon">
            <i class="ion ion-stats-bars"></i>
          </div>
          <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
          <div class="inner">
            <h3>{{$product}}</h3>

            <p>Product can Sell</p>
          </div>
          <div class="icon">
            <i class="ion ion-person-add"></i>
          </div>
          <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
          <div class="inner">
            <h3>{{$ReJected}}</h3>

            <p>ReJected</p>
          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- ./col -->
    </div>
    <!-- /.row -->
    <!-- Main row -->

    <!-- /.row (main row) -->
  </div><!-- /.container-fluid -->
  <script src="../plugins/jquery/jquery.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDetYAHVFFW-fBj_STo3C9a6Nb7lFZxiHc&callback=initMap&libraries=&v=weekly" defer></script>
  <script>
    let map;


    function initMap() {


        const myLatLng = {
            lat: 6.053519,
            lng: 80.220978
        };

        map = new google.maps.Map(document.getElementById("map"), {
            center: myLatLng,
            zoom: 15
        });

        var marker = new google.maps.Marker({
                  position: myLatLng,

                map,
            animation: google.maps.Animation.BOUNCE,
            title: "Hello World!"
        });

   var database = firebase.database();
  var LocationRef = firebase.database().ref("company"+{{request()->session()->get('Company')}}+"/Location");
  LocationRef.on('value', function(snapshot) {


                const val = snapshot.val()
                val.forEach(element => {
                  const myLatLng = {
                      lat: parseFloat(element.latitude),
                    lng: parseFloat(element.longitude)
                 };
                 marker.setPosition(myLatLng);
              });

      });





    }
    </script>
@endsection
