<!DOCTYPE html>
<html>
<head>
    @if(request()->session()->get('AdminLogin'))
    <script>window.location = "/dashboard";</script>
    @endif
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>{{ env('APP_NAME')}} | Register</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{{ URL::asset('plugins/toastr/toastr.min.css') }}">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="p-5">
<div class="container">
    <div class="row mb-3">
        <div class="col-md-12">
            <h3 class="text-center">{{env('APP_NAME')}} Farmer - Registaton</h3>
        </div>
    </div>
        <div class="row">

            <div class="col-md-6">

                {{ Form::open(array('url' => '/farmer/registation/prosess','method'=>'POST')) }}

                <div class="card">
                    <div class="card-body">
                        <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" required class="form-control" id="FullName" name="FullName">
                                                <label for="FullName">Full Name</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" required class="form-control" id="NIC" name="NIC">
                                                <label for="NIC">NIC No.</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="password" class="form-control" id="Password" name="Password">
                                                <label for="Password">Password</label>
                                            </div>
                                        </div>
                                    </div>
                                <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="TP" name="TP">
                                                <label for="TP">Tel No</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="Address1" name="Address1">
                                                <label for="Address1">Address Line 1</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="Address2" name="Address2">
                                                <label for="Address2">Address Line 2</label>
                                            </div>
                                        </div>
                                    </div>
                                                                        <div class="form-group row mt-2">
                                        <div class="col-8">
                                            <div class="form-material">
                                                <select class="js-select2 form-control" id="District_idDistrict" name="District_idDistrict" style="width: 100%;" data-placeholder="Choose one..">
                                                   <option></option><!-- Required for data-placeholder attribute to work with Select2 plugin -->
                                                    @foreach ($districts as $item)
                                                    <option value="{{$item->idDistrict}}">{{$item->DistrictName}}</option>
                                                    @endforeach
                                                </select>
                                                <label for="District_idDistrict">District</label>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="ZipCode" name="ZipCode">
                                                <label for="ZipCode">ZipCode</label>
                                            </div>
                                        </div>
                                    </div>

                    </div>
                </div>





</div>
                                    <div class="col-md-6">
                                                        <div class="card">
                    <div class="card-body">
                                   <div class="form-group row">
                                       <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio neque natus autem error architecto sapiente, esse quaerat, eligendi animi inventore ea maxime possimus iusto omnis provident ut minus maiores aliquid.</p>
                                    </div>
                                    <div class="form-group row text-center">
                                        <div class="col-12">
                                            <label class="css-control css-control-primary css-checkbox">
                                                <input type="checkbox" class="css-control-input" required id="signup-terms" name="signup-terms">
                                                <span class="css-control-indicator"></span>
                                                I agree to Terms &amp; Conditions
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group row gutters-tiny">
                                        <div class="col-12 mb-2 ">
                                            <button  style="color: aliceblue; background-color: rgb(134, 108, 158)" type="submit" class="btn btn-block btn-hero btn-noborder btn-rounded btn-alt-success">
                                                <i class="si si-user-follow mr-10"></i> Sign Up
                                            </button>
                                        </div>
                                        {{ Form::close() }}


                                        <div class="col-6">
                                            <a style="color: aliceblue; background-color: blueviolet"  class="btn btn-block btn-noborder btn-rounded btn-alt-secondary" href="#" data-toggle="modal" data-target="#modal-terms">
                                                <i class="si si-book-open text-muted mr-10"></i> Read Terms
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a  style="color: aliceblue; background-color: blueviolet" class="btn btn-block btn-noborder btn-rounded btn-alt-secondary" href="/farmer/login">
                                                <i class="si si-login text-muted mr-10"></i> Sign In
                                            </a>
                                        </div>
                                    </div>
                    </div>
                </div>
                                    </div>
        </div>
</div>

<script type="text/javascript" src="{{ URL::asset('plugins/jquery/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('plugins/toastr/toastr.min.js') }}"></script>
        {{-- <script>jQuery(function () { Codebase.helpers('select2'); });</script> --}}

<script>
    $(document).ready(function () {


        @if(Session::has('message'))
      var type = "{{ Session::get('alert-type', 'info') }}";

      switch(type){

          case 'success':
          toastr.success("{{ Session::get('message') }}")
            break;

          case 'error':
          toastr.error("{{ Session::get('message') }}")
            break;

          case 'info':
          toastr.info("{{ Session::get('message') }}")
            break;

          case 'warning':
          toastr.warning("{{ Session::get('message') }}")
            break;
      }
    @endif
    toastr.options.closeButton = true;

    });

</script>


</body>
</html>
