<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Farmer;
use App\Http\Controllers\doa;
use App\Http\Controllers\webM;
use App\Http\Controllers\keels;
use App\Http\Controllers\Dashbord;
use App\Http\Controllers\Product;
use App\Http\Controllers\mapView;
use App\Http\Controllers\msg;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [Farmer::class, 'checklogin']);
Route::get('/farmer', [Farmer::class, 'checklogin']);
Route::get('/farmer/login', [Farmer::class, 'loginView']);
Route::post('/farmer/login/prosess', [Farmer::class, 'LoginProsess']);
Route::get('/farmer/registation', [Farmer::class, 'RegView']);
Route::post('/farmer/registation/prosess', [Farmer::class, 'RegistationProsess']);
Route::post('/farmer/Forget', [Farmer::class, 'forgetView']);
Route::post('/farmer/Forget/{nic}', [Farmer::class, 'forgetPass']);
Route::get('/farmer/logout', [Farmer::class, 'logout']);

Route::get('/farmer/dashboard', [Dashbord::class, 'index']);

Route::get('/farmer/product', [Product::class, 'index']);
Route::get('/farmer/product/AddNewView', [Product::class, 'AddNewView']);
Route::post('/farmer/product/AddNewView/save', [Product::class, 'saveProduct']);
Route::post('/farmer/product/AddNewView/update', [Product::class, 'updateProduct']);
Route::get('/farmer/product/delete/{id}', [Product::class, 'DeleteProduct']);
Route::get('/farmer/product/edit/{id}', [Product::class, 'indexEdit']);
Route::get('/farmer/product/img/{id}', [Product::class, 'deleteIMG']);


Route::get('/farmer/msgView', [msg::class, 'farmerIndex']);
Route::get('/farmer/msg/{keels}', [msg::class, 'msgViewF']);
Route::post('/farmer/msg/send', [msg::class, 'sendfarmer']);
Route::get('/farmer/msg/delete/{id}', [msg::class, 'delete']);


Route::get('/keels', [keels::class, 'checklogin']);
Route::get('/keels/login', [keels::class, 'loginView']);
Route::post('/keels/login/prosess', [keels::class, 'LoginProsess']);
Route::post('/keels/Forget', [keels::class, 'forgetView']);
Route::post('/keels/Forget/{nic}', [keels::class, 'forgetPass']);
Route::get('/keels/logout', [keels::class, 'logout']);


Route::get('/keels/dashboard', [Dashbord::class, 'keelsIndex']);
Route::get('/keels/MapView', [mapView::class, 'index']);
Route::get('/keels/MarkForbrought', [mapView::class, 'viewMarked']);
Route::get('/keels/rejected', [mapView::class, 'viewRejected']);

Route::get('/keels/msgView', [msg::class, 'Keelsindex']);
Route::get('/keels/msg/{farmer}', [msg::class, 'msgViewK']);
Route::post('/keels/msg/send', [msg::class, 'sendKeels']);
Route::get('/keels/msg/delete/{id}', [msg::class, 'delete']);


Route::get('/product/reject/{id}', [Product::class, 'rejectItem']);
Route::get('/product/buy/{id}', [Product::class, 'broughtItem']);
Route::get('/product/markforbuy/{id}', [Product::class, 'markForBuy']);
Route::get('/product/falg/{id}/{no}', [Product::class, 'flag']);


Route::get('/admin/keelsAgent', [keels::class, 'indexKeeels']);
Route::post('/admin/keelsAgent/add', [keels::class, 'AddKeels']);
Route::post('/admin/keelsAgent/update', [keels::class, 'updateKeels']);
Route::post('/admin/keelsAgent/changePass', [keels::class, 'forgetPass']);
Route::get('/admin/keelsAgent/disable/{id}', [keels::class, 'disableKeels']);
Route::get('/admin/keelsAgent/delete/{id}', [keels::class, 'deleteKeels']);

Route::get('/admin/doaAgent', [doa::class, 'Doaindex']);
Route::post('/admin/doaAgent/add', [doa::class, 'Add']);
Route::post('/admin/doaAgent/update', [doa::class, 'update']);
Route::get('/admin/doaAgent/disable/{id}', [doa::class, 'disable']);
Route::post('/admin/doaAgent/changePass', [doa::class, 'forgetPass']);
Route::get('/admin/doaAgent/delete/{id}', [doa::class, 'delete']);

Route::get('/doa', [doa::class, 'checklogin']);
Route::get('/doa/login', [doa::class, 'loginView']);
Route::post('/doa/login/prosess', [doa::class, 'LoginProsess']);
Route::post('/doa/Forget', [doa::class, 'forgetView']);
Route::post('/doa/Forget/{nic}', [doa::class, 'forgetPass']);
Route::get('/doa/logout', [doa::class, 'logout']);
Route::get('/doa', [doa::class, 'checklogin']);

Route::get('/doa/dashboard', [Dashbord::class, 'doaIndex']);
Route::get('/doa/all', [mapView::class, 'viewDaoMap']);
Route::get('/doa/reject', [mapView::class, 'viewRejectDOA']);
Route::get('/doa/brought', [mapView::class, 'viewbrought']);

Route::get('/admin/dashboard', [Dashbord::class, 'webMIndex']);



Route::post('/admin/webMAgent', [webM::class, 'index']);
Route::post('/admin/webMAgent/add', [webM::class, 'Add']);
Route::post('/admin/webMAgent/update', [webM::class, 'update']);
Route::post('/admin/webMAgent/disable/{id}', [webM::class, 'disable']);
Route::post('/admin/webMAgent/delete/{id}', [webM::class, 'delete']);

Route::get('/admin', [webM::class, 'checklogin']);
Route::get('/admin/login', [webM::class, 'loginView']);
Route::post('/admin/login/prosess', [webM::class, 'LoginProsess']);
Route::post('/admin/Forget', [webM::class, 'forgetView']);
Route::post('/admin/Forget/{nic}', [webM::class, 'forgetPass']);
Route::get('/admin/logout', [webM::class, 'logout']);
Route::get('/admin', [webM::class, 'checklogin']);


Route::get('/imageList/{id}', [Product::class, 'getProductImage']);

Route::get('/sucsess/{id}', [Product::class, 'markForBuy']);
Route::get('/reject/{id}', [Product::class, 'rejectItem']);
Route::get('/brought/{id}', [Product::class, 'broughtItem']);
Route::get('/flag/{id}/{flag}', [Product::class, 'flag']);