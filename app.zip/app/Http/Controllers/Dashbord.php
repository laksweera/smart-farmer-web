<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Dashbord extends Controller
{
    function index()
    {
        $pendin = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsBrought', 0)
            ->where('IsReject', 0)
            ->where('Status', 1)
            ->where('farmer_idfarmer', request()->session()->get('FarmerID'))
            ->count();
        $product = DB::table('product')
            ->count();
        $Brought = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsBrought', 1)
            ->where('Status', 1)
            ->where('farmer_idfarmer', request()->session()->get('FarmerID'))
            ->count();
        $ReJected = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsReject', 1)
            ->where('Status', 1)
            ->where('farmer_idfarmer', request()->session()->get('FarmerID'))
            ->count();
        return view('farmer.Dashbord')->with("pendin", $pendin)->with("product", $product)->with("Brought", $Brought)->with("ReJected", $ReJected);;
    }

    function keelsIndex()
    {
        $Brought = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsBrought', 1)
            ->where('Status', 1)
            ->count();
        $ReJected = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsReject', 1)
            ->where('Status', 1)
            ->count();
        $farmer = DB::table('doa')
            ->where('SoftDelete', 0)
            ->where('Status', 1)
            ->count();

        $product = DB::table('product')
            ->count();
        return view('keels.Dashbord')->with("farmer", $farmer)->with("product", $product)->with("Brought", $Brought)->with("ReJected", $ReJected);
    }

    function doaIndex()
    {
        $Brought = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsBrought', 1)
            ->where('Status', 1)
            ->count();
        $ReJected = DB::table('product_recode')
            ->where('SoftDelete', 0)
            ->where('IsReject', 1)
            ->where('Status', 1)
            ->count();
        $farmer = DB::table('doa')
            ->where('SoftDelete', 0)
            ->where('Status', 1)
            ->count();

        $product = DB::table('product')
            ->count();
        return view('doa.Dashbord')->with("farmer", $farmer)->with("product", $product)->with("Brought", $Brought)->with("ReJected", $ReJected);;
    }

    function webMIndex()
    {
        return view('admin.Dashbord');
    }
}