<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class msg extends Controller
{
    function Keelsindex()
    {
        $users = DB::table('maseges')
            ->join("farmer", "farmer.idfarmer", "=", "maseges.farmer_idfarmer")
            ->where('keels_idkeels', request()->session()->get('keelsID'))
            ->distinct('farmer.idfarmer')
            ->select("farmer.FullName", 'farmer.idfarmer')
            ->get();

        return view("keels.sms_view")->with("users", $users);
    }

    function farmerIndex()
    {
        $users = DB::table('maseges')
            ->join("keels", "keels.idkeels", "=", "maseges.keels_idkeels")
            ->where('farmer_idfarmer', request()->session()->get('FarmerID'))
            ->distinct('keels.idkeels')
            ->select("keels.idkeels", 'keels.keelsAgentName')
            ->get();
        return view("farmer.sms_view")->with("users", $users);
    }



    function msgViewF($keels)
    {
        $msg = DB::table('maseges')
            ->where('farmer_idfarmer', request()->session()->get('FarmerID'))
            ->where('keels_idkeels', $keels)
            ->get();
        return view("farmer.sms")->with("msg", $msg)->with("keels", $keels);
    }


    function msgViewK($farmer)
    {
        $msg = DB::table('maseges')
            ->where('farmer_idfarmer', $farmer)
            ->where('keels_idkeels', request()->session()->get('keelsID'))
            ->get();

        return view("keels.sms")->with("msg", $msg)->with("farmer", $farmer);
    }

    function sendKeels(Request $req)
    {
        $save = DB::table('maseges')->insert(
            [
                'farmer_idfarmer' => $req->input('farmer'),
                'keels_idkeels' =>  request()->session()->get('keelsID'),
                'IsFromKeels' => 1,
                'msg' => $req->input('msg'),
            ]
        );

        if ($save) {
            return redirect()
                ->back();
        } else {
            $notification = array(
                'message' => 'Send fail',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }

    function sendfarmer(Request $req)
    {
        $save = DB::table('maseges')->insert(
            [
                'farmer_idfarmer' => request()->session()->get('FarmerID'),
                'keels_idkeels' =>  $req->input('keels'),
                'IsFromKeels' => 0,
                'msg' => $req->input('msg'),
            ]
        );

        if ($save) {
            return redirect()
                ->back();
        } else {
            $notification = array(
                'message' => 'Send fail',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }

    function delete($id)
    {
        $update = DB::table('maseges')
            ->where('idmaseges', $id)
            ->update([
                "Status" => 0,

            ]);

        if ($update) {
            return redirect()
                ->back();
        } else {
            $notification = array(
                'message' => 'Delete fail',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
}