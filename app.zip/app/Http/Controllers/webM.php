<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class webM extends Controller
{


    function checklogin()
    {
        $user = request()->session()->get('webMLogin');
        if ($user) {
            return Redirect::to('/admin/dashboard');
        } else {
            return Redirect::to('/admin/login');
        }
    }

    function forgetView()
    {
        return view('admin.Layout.login');
    }

    function loginView()
    {
        return view('admin.Layout.login');
    }



    function LoginProsess(Request $req)
    {
        $email = $req->input('AdminUName');
        $pass = $req->input('AdminPassword');

        $user = DB::table('Admin')
            ->where('AdminUName', $email)->first();

        if (isset($user->idAdmin)) {
            if (Hash::check($pass, $user->AdminPassword)) {

                if ($user->Status == 1) {
                    request()->session()->put('webMLogin', true);
                    request()->session()->put('idAdmin', $user->idAdmin);
                    request()->session()->put('AdminName', $user->AdminName);
                    request()->session()->put('AdminUName', $user->AdminUName);


                    $notification = array(
                        'message' => 'wellcome back ' . $user->AdminName . ' ',
                        'alert-type' => 'success'
                    );
                    return Redirect::to('/admin/dashboard')->with($notification);
                } else {

                    $notification = array(
                        'message' => 'Sorry Your Account has been disabled',
                        'alert-type' => 'warning'
                    );
                    return redirect()
                        ->back()
                        ->withInput()
                        ->with($notification);
                }
            } else {

                $notification = array(
                    'message' => 'Wrong credentials  if you have any problem please contact us',
                    'alert-type' => 'error'
                );
                return redirect()
                    ->back()
                    ->withInput()
                    ->with($notification);
            }
        } else {

            $notification = array(
                'message' => 'Wrong credentials  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }

    function AddwebM(Request $req)
    {
        $save = DB::table('Admin')->insert(
            [
                'AdminName' => $req->input('AdminName'),
                'AdminUName' => $req->input('AdminUName'),
                'webMAgentRegNo' => $req->input('webMAgentRegNo'),
                'webMAgentEmail' => $req->input('webMAgentEmail'),
                'AdminPassword' => Hash::make($req->input('AdminPassword')),
            ]
        );


        if ($save) {
            $notification = array(
                'message' => 'You have sucsessfuly Add webM Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/webMAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function deletewebM($id)
    {
        $update = DB::table('Admin')
            ->where('idAdmin', $id)
            ->update([
                "SoftDelete" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Delete webM Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function disablewebM($id)
    {
        $update = DB::table('Admin')
            ->where('idAdmin', $id)
            ->update([
                "Status" => 0,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Disable webM Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function updatewebM(Request $req)
    {
        $update = DB::table('Admin')
            ->where('idAdmin', $req->input('idAdmin'))
            ->update([
                'AdminName' => $req->input('AdminName'),
                'AdminUName' => $req->input('AdminUName'),
                'webMAgentRegNo' => $req->input('webMAgentRegNo'),
                'webMAgentEmail' => $req->input('webMAgentEmail'),
                'AdminPassword' => Hash::make($req->input('AdminPassword')),

            ]);


        if ($update) {
            $notification = array(
                'message' => 'Successfully Update webM Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/Admin')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }


    function index()
    {
        $webMAgets = DB::table('Admin')
            ->where("SoftDelete", 0)
            ->get();
        return view('admin.webMAgets')->with("webMAgets", $webMAgets);
    }

    function forgetPass($email)
    {
    }
    function logout()
    {
        $logout = Request()->session()->flush();
        return Redirect::to('/admin/login');
    }
}