<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class doa extends Controller
{

    function checklogin()
    {
        $user = request()->session()->get('doaLogin');
        if ($user) {
            return Redirect::to('/doa/dashboard');
        } else {
            return Redirect::to('/doa/login');
        }
    }

    function forgetView()
    {
        return view('doa.Layout.login');
    }

    function loginView()
    {
        return view('doa.Layout.login');
    }



    function LoginProsess(Request $req)
    {
        $email = $req->input('doaEmail');
        $pass = $req->input('doaPassword');

        $user = DB::table('doa')
            ->where('doaEmail', $email)->first();

        if (isset($user->iddoa)) {
            if (Hash::check($pass, $user->doaPassword)) {

                if ($user->Status == 1) {
                    request()->session()->put('doaLogin', true);
                    request()->session()->put('doaID', $user->iddoa);
                    request()->session()->put('doaEmail', $user->doaEmail);
                    request()->session()->put('doaName', $user->doaName);


                    $notification = array(
                        'message' => 'wellcome back ' . $user->doaName . ' ',
                        'alert-type' => 'success'
                    );
                    return Redirect::to('/doa/dashboard')->with($notification);
                } else {

                    $notification = array(
                        'message' => 'Sorry Your Account has been disabled',
                        'alert-type' => 'warning'
                    );
                    return redirect()
                        ->back()
                        ->withInput()
                        ->with($notification);
                }
            } else {

                $notification = array(
                    'message' => 'Wrong credentials  if you have any problem please contact us',
                    'alert-type' => 'error'
                );
                return redirect()
                    ->back()
                    ->withInput()
                    ->with($notification);
            }
        } else {

            $notification = array(
                'message' => 'Wrong credentials  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }

    function Add(Request $req)
    {
        $save = DB::table('doa')->insert(
            [
                'doaName' => $req->input('doaName'),
                'doaEmail' => $req->input('doaEmail'),
                'doaPassword' => Hash::make($req->input('doaPassword')),
            ]
        );


        if ($save) {
            $notification = array(
                'message' => 'You have sucsessfuly Add doa Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/doaAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function delete($id)
    {
        $update = DB::table('doa')
            ->where('iddoa', $id)
            ->update([
                "SoftDelete" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Delete doa Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function disable($id)
    {
        $data = DB::table('doa')
            ->where("iddoa", $id)
            ->select("Status")
            ->first();

        if ($data->Status == 1) {
            $st = 0;
        } else {
            $st = 1;
        }
        $update = DB::table('doa')
            ->where('iddoa', $id)
            ->update([
                "Status" => $st,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Disable doa Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function update(Request $req)
    {
        $update = DB::table('doa')
            ->where('iddoa', $req->input('iddoa'))
            ->update([
                'doaName' => $req->input('doaName'),
                'doaEmail' => $req->input('doaEmail'),

            ]);


        if ($update) {
            $notification = array(
                'message' => 'Successfully Update doa Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/doaAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }


    function Doaindex()
    {

        $doaS = DB::table('doa')
            ->where("SoftDelete", 0)
            ->get();

        $all = DB::table('doa')
            ->where("SoftDelete", 0)
            ->count();

        $active = DB::table('doa')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();

        $deactive = DB::table('doa')
            ->where("SoftDelete", 0)
            ->where("Status", 0)
            ->count();

        return view('admin.doa')
            ->with("doaS", $doaS)
            ->with("all", $all)
            ->with("active", $active)
            ->with("deactive", $deactive);
    }


    function forgetPass(Request $req)
    {
        $update = DB::table('doa')
            ->where('iddoa', $req->input('iddoa'))
            ->update([
                'doaPassword' => Hash::make($req->input('newPassword')),
            ]);


        if ($update) {
            $notification = array(
                'message' => 'Successfully Chenge Password DOA Officer',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/doaAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function logout()
    {
        $logout = Request()->session()->flush();
        return Redirect::to('/doa/login');
    }
}