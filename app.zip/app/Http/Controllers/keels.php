<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class keels extends Controller
{
    function indexKeeels()
    {

        $keelsAgents = DB::table('keels')
            ->where("SoftDelete", 0)
            ->get();

        $all = DB::table('keels')
            ->where("SoftDelete", 0)
            ->count();

        $active = DB::table('keels')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();

        $deactive = DB::table('keels')
            ->where("SoftDelete", 0)
            ->where("Status", 0)
            ->count();

        return view('admin.keels')
            ->with("keelsAgents", $keelsAgents)
            ->with("all", $all)
            ->with("active", $active)
            ->with("deactive", $deactive);
    }

    function checklogin()
    {
        $user = request()->session()->get('keelsLogin');
        if ($user) {
            return Redirect::to('/keels/dashboard');
        } else {
            return Redirect::to('/keels/login');
        }
    }

    function forgetView()
    {
        return view('keels.Layout.login');
    }

    function loginView()
    {
        return view('keels.Layout.login');
    }



    function LoginProsess(Request $req)
    {
        $email = $req->input('keelsEMPno');
        $pass = $req->input('keelsAgentPassword');

        $user = DB::table('keels')
            ->where('keelsEMPno', $email)->first();

        if (isset($user->idkeels)) {
            if (Hash::check($pass, $user->keelsAgentPassword)) {

                if ($user->Status == 1) {
                    request()->session()->put('keelsLogin', true);
                    request()->session()->put('keelsID', $user->idkeels);
                    request()->session()->put('keelsEMPno', $user->keelsEMPno);
                    request()->session()->put('keelsName', $user->keelsAgentName);

                    $notification = array(
                        'message' => 'wellcome back ' . $user->keelsAgentName . ' ',
                        'alert-type' => 'success'
                    );
                    return Redirect::to('/keels/dashboard')->with($notification);
                } else {

                    $notification = array(
                        'message' => 'Sorry Your Account has been disabled',
                        'alert-type' => 'warning'
                    );
                    return redirect()
                        ->back()
                        ->withInput()
                        ->with($notification);
                }
            } else {

                $notification = array(
                    'message' => 'Wrong credentials  if you have any problem please contact us',
                    'alert-type' => 'error'
                );
                return redirect()
                    ->back()
                    ->withInput()
                    ->with($notification);
            }
        } else {

            $notification = array(
                'message' => 'Wrong credentials  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }

    function AddKeels(Request $req)
    {
        $save = DB::table('keels')->insert(
            [

                'keelsAgentName' => $req->input('keelsAgentName'),
                'keelsEMPno' => $req->input('keelsEMPno'),
                'keelsAgentPassword' => Hash::make($req->input('keelsAgentPassword')),
            ]
        );


        if ($save) {
            $notification = array(
                'message' => 'You have sucsessfuly Add Keels Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/keelsAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function deleteKeels($id)
    {
        $update = DB::table('keels')
            ->where('idkeels', $id)
            ->update([
                "SoftDelete" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Delete Keels Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function disableKeels($id)
    {
        $data = DB::table('keels')
            ->where("idkeels", $id)
            ->select("Status")
            ->first();

        if ($data->Status == 1) {
            $st = 0;
        } else {
            $st = 1;
        }
        $update = DB::table('keels')
            ->where('idkeels', $id)
            ->update([
                "Status" => $st,
            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Disable Keels Agent',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function updateKeels(Request $req)
    {
        $update = DB::table('keels')
            ->where('idkeels', $req->input('idkeels'))
            ->update([

                'keelsAgentName' => $req->input('keelsAgentName'),
                'keelsEMPno' => $req->input('keelsEMPno'),
            ]);


        if ($update) {
            $notification = array(
                'message' => 'Successfully Update Keels Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/keelsAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }




    function forgetPass(Request $req)
    {
        $update = DB::table('keels')
            ->where('idkeels', $req->input('idkeels'))
            ->update([
                'keelsAgentPassword' => Hash::make($req->input('newPassword')),
            ]);


        if ($update) {
            $notification = array(
                'message' => 'Successfully Chenge Password Keels Agent',
                'alert-type' => 'success'
            );
            return Redirect::to('/admin/keelsAgent')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function logout()
    {
        $logout = Request()->session()->flush();
        return Redirect::to('/keels/login');
    }
}