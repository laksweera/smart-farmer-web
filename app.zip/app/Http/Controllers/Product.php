<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;

class Product extends Controller
{
    function index()
    {
        $productRecode = DB::table('product_recode')
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->where("product_recode.Status", 1)
            ->orderByDesc('product_recode.idproduct_recode')
            ->get();

        $all = DB::table('product_recode')
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->count();
        $notRate = DB::table('product_recode')
            ->where("product_recode.FlagNo", 0)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->where("product_recode.Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("product_recode.IsMarkedForBuy", 1)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->where("product_recode.Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("product_recode.IsReject", 1)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->where("product_recode.Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("product_recode.IsBrought", 1)
            ->where("product_recode.farmer_idfarmer", request()->session()->get('FarmerID'))
            ->where("product_recode.Status", 1)
            ->count();
        return view('farmer.Product')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
    }


    function indexEdit($id)
    {
        $productRecode = DB::table('product_recode')
            ->where("idproduct_recode", $id)
            ->first();
        $productImg = DB::table('image')
            ->where("product_recode_idproduct_recode", $id)
            ->get();
        $productType = DB::table('product')
            ->get();
        $mesurementS = DB::table('mesurement')
            ->get();
        return view('farmer.EditProduct')
            ->with("productRecode", $productRecode)
            ->with("productImg", $productImg)
            ->with("idProduct_Recode", $id)
            ->with("productType", $productType)
            ->with("mesurementS", $mesurementS);
    }

    function AddNewView()
    {
        $productType = DB::table('product')
            ->get();
        $mesurementS = DB::table('mesurement')
            ->get();
        return view('farmer.NewProduct')->with("productType", $productType)->with("mesurementS", $mesurementS);
    }

    function saveProduct(Request $req)
    {
        $productID = DB::table('product_recode')->insertGetId(
            [
                'farmer_idfarmer' => request()->session()->get('FarmerID'),
                'product_idproduct' => $req->input('product_idproduct'),
                'Mesurement_idMesurement' => $req->input('Mesurement_idMesurement'),
                'Discription' => $req->input('Discription'),
                'unitCount' => $req->input('unitCount'),
                'pickedDate' => $req->input('pickedDate'),
                'latitude' => $req->input('latitude'),
                'Longitude' => $req->input('Longitude'),
            ]
        );
        foreach ($req->file('Image') as $files) {
            $fileName = time() . '_' . $files->getFilename() . "." . $files->getClientOriginalExtension();
            $filePath = $files->storeAs('ProductImg', $fileName, 'public');
            $tumb = '/storage/' . $filePath;

            $save = DB::table('image')->insert(
                [
                    'product_recode_idproduct_recode' => $productID,
                    'ImageUrl' => $tumb,

                ]
            );
        };

        if ($save) {
            $notification = array(
                'message' => 'You have sucsessfuly Add recode',
                'alert-type' => 'success'
            );
            return Redirect::to('/farmer/product')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function DeleteProduct($id)
    {
        $update = DB::table('product_recode')
            ->where('idproduct_recode', $id)
            ->update([
                "SoftDelete" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Delete Product',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function updateProduct(Request $req)
    {
        try {
            $update = DB::table('product_recode')
                ->where('idProduct_Recode', $req->input('idProduct_Recode'))
                ->update([
                    'product_idproduct' => $req->input('product_idproduct'),
                    'Mesurement_idMesurement' => $req->input('Mesurement_idMesurement'),
                    'Discription' => $req->input('Discription'),
                    'unitCount' => $req->input('unitCount'),
                    'pickedDate' => $req->input('pickedDate'),
                    'latitude' => $req->input('latitude'),
                    'Longitude' => $req->input('Longitude'),

                ]);

            if ($req->file('Image')) {
                foreach ($req->file('Image') as $files) {
                    $fileName = time() . '_' . $files->getFilename() . "." . $files->getClientOriginalExtension();
                    $filePath = $files->storeAs('ProductImg', $fileName, 'public');
                    $tumb = '/storage/' . $filePath;

                    $save = DB::table('image')->insert(
                        [
                            'product_recode_idproduct_recode' => $req->input('idProduct_Recode'),
                            'ImageUrl' => $tumb,

                        ]
                    );
                };
            }
        } catch (\Throwable $th) {
            //throw $th;
        }

        if ($update) {
            $notification = array(
                'message' => 'Successfully Update Product',
                'alert-type' => 'success'
            );
            return Redirect::to('/farmer/product')->with($notification);
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function deleteIMG($id)
    {
        $productImg = DB::table('image')
            ->where("idImage", $id)
            ->first();

        $delete = DB::table('image')
            ->where("idImage", $id)
            ->delete();

        if ($delete) {
            Storage::delete("$productImg->ImageUrl");
            // unlink(storage_path('app/folder/' . $file));
            return 1;
        }
    }

    function broughtItem($id)
    {
        $update = DB::table('product_recode')
            ->where('idproduct_recode', $id)
            ->update([
                "IsBrought" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Brought Item',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }

    function rejectItem($id)
    {
        $update = DB::table('product_recode')
            ->where('idproduct_recode', $id)
            ->update([
                "IsReject" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Mark as Rejected',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }

    function flag($id, $flag)
    {
        $update = DB::table('product_recode')
            ->where('idproduct_recode', $id)
            ->update([
                "FlagNo" => $flag,
            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Add Responce',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }

    function markForBuy($id)
    {
        $update = DB::table('product_recode')
            ->where('idproduct_recode', $id)
            ->update([
                "IsMarkedForBuy" => 1,

            ]);

        if ($update) {
            $notification = array(
                'message' => 'Successfully Mark For Buy',
                'alert-type' => 'success'
            );
        } else {
            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
        }
        return redirect()
            ->back()
            ->with($notification);
    }
    function getProductImage($id)
    {
        $productImg = DB::table('image')
            ->where("product_recode_idproduct_recode", $id)
            ->get();

        return $productImg;
    }
}