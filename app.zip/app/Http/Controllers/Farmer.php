<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class Farmer extends Controller
{

    function checklogin()
    {
        $user = request()->session()->get('FarmerLogin');
        if ($user) {
            return Redirect::to('/farmer/dashboard');
        } else {
            return Redirect::to('/farmer/login');
        }
    }

    function forgetView()
    {
        return view('farmer.Layout.login');
    }

    function loginView()
    {
        return view('farmer.Layout.login');
    }

    function RegView()
    {
        $districts = DB::table('district')
            ->get();
        return view('farmer.Layout.Register')->with("districts", $districts);
    }

    function LoginProsess(Request $req)
    {
        $NIC = $req->input('NIC');
        $pass = $req->input('password');

        $user = DB::table('farmer')
            ->where('NIC', $NIC)->first();

        if (isset($user->idfarmer)) {
            if (Hash::check($pass, $user->Password)) {

                if ($user->Status == 1) {
                    request()->session()->put('FarmerLogin', true);
                    request()->session()->put('FarmerID', $user->idfarmer);
                    request()->session()->put('FarmerName', $user->FullName);

                    $notification = array(
                        'message' => 'wellcome back ' . $user->FullName . ' ',
                        'alert-type' => 'success'
                    );
                    return Redirect::to('/farmer/dashboard')->with($notification);
                } else {

                    $notification = array(
                        'message' => 'Sorry Your Account has been disabled',
                        'alert-type' => 'warning'
                    );
                    return redirect()
                        ->back()
                        ->withInput()
                        ->with($notification);
                }
            } else {

                $notification = array(
                    'message' => 'Wrong credentials  if you have any problem please contact us',
                    'alert-type' => 'error'
                );
                return redirect()
                    ->back()
                    ->withInput()
                    ->with($notification);
            }
        } else {

            $notification = array(
                'message' => 'Wrong credentials  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function RegistationProsess(Request $req)
    {
        $validatedData = $req->validate([
            'NIC' => 'required|unique:farmer',
        ]);



        $user = DB::table('farmer')->insert(
            [
                'FullName' => $req->input('FullName'),
                'NIC' => $req->input('NIC'),
                'Password' => Hash::make($req->input('Password')),
                'District_idDistrict' => $req->input('District_idDistrict'),
                'TP' => $req->input('TP'),
                'Address1' => $req->input('Address1'),
                'Address2' => $req->input('Address2'),
                'City' => $req->input('City'),
                'ZipCode' => $req->input('ZipCode'),

            ]
        );

        if ($user) {
            $notification = array(
                'message' => 'You have sucsessfuly Register',
                'alert-type' => 'success'
            );
            return Redirect::to('/farmer/login')->with($notification);
        } else {

            $notification = array(
                'message' => 'something When wrong  if you have any problem please contact us',
                'alert-type' => 'error'
            );
            return redirect()
                ->back()
                ->withInput()
                ->with($notification);
        }
    }
    function forgetPass($nic)
    {
    }
    function logout()
    {
        $logout = Request()->session()->flush();
        return Redirect::to('/farmer/login');
    }
}