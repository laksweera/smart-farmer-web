<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class mapView extends Controller
{
    function index()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsReject", 0)
            ->where("product_recode.IsBrought", 0)
            ->where("product_recode.IsMarkedForBuy", 0)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('keels.mapView')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
        // print_r($productRecode);
    }


    function viewMarked()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsReject", 0)
            ->where("product_recode.IsBrought", 0)
            ->where("product_recode.IsMarkedForBuy", 1)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('keels.broughtView')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
    }

    function viewRejected()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsReject", 1)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('keels.rejectView')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
    }

    function viewDaoMap()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsReject", 0)
            ->where("product_recode.IsBrought", 0)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('doa.mapView')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);

        // print_r($productRecode);
    }
    function viewRejectDOA()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsReject", 1)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('doa.rejected')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
    }
    function viewbrought()
    {
        $productRecode = DB::table('product_recode')
            ->join("farmer", "farmer.idfarmer", "=", "product_recode.farmer_idfarmer")
            ->join("product", "product.idproduct", "=", "product_recode.product_idproduct")
            ->join("district", "district.idDistrict", "=", "farmer.District_idDistrict")
            ->join("mesurement", "mesurement.idMesurement", "=", "product_recode.Mesurement_idMesurement")
            ->where("product_recode.SoftDelete", 0)
            ->where("product_recode.Status", 1)
            ->where("product_recode.IsBrought", 1)
            ->orderByDesc('product_recode.idproduct_recode')
            ->select("farmer.*", "farmer.DateTime as FDateTime", "product_recode.DateTime as PDateTime", "product.productName", "product_recode.*", "district.DistrictName")
            ->get();

        $all = DB::table('product_recode')
            ->where("SoftDelete", 0)
            ->where("Status", 1)
            ->count();
        $notRate = DB::table('product_recode')
            ->where("FlagNo", 0)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $pending = DB::table('product_recode')
            ->where("IsMarkedForBuy", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $Rejected = DB::table('product_recode')
            ->where("IsReject", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        $broughted = DB::table('product_recode')
            ->where("IsBrought", 1)
            ->where("Status", 1)
            ->where("Status", 1)
            ->count();
        return view('doa.brought')
            ->with("productRecode", $productRecode)
            ->with("all", $all)
            ->with("notRate", $notRate)
            ->with("pending", $pending)
            ->with("Rejected", $Rejected)
            ->with("broughted", $broughted);
    }
}